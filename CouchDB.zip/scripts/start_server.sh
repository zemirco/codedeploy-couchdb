#!/bin/bash

# start couchdb as couchdb user
sudo -i -u couchdb couchdb
